drop procedure if exists teste;
drop database if exists crud;
