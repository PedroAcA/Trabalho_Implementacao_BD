insert into crud_partido values (1, 'MDB', 'Brasília', 'Romero Jucá Filho', 2000000, '1981-06-30');
insert into crud_partido values (2, 'PT', 'São Paulo', 'Gleisi Helena Hoffmann', 1500000, '1982-02-11');
insert into crud_partido values (3, 'PSDB', 'Brasília', 'Geraldo Alckmin', 1400000, '1989-08-24');
insert into crud_partido values (4, 'PSL', 'Brasília', 'Gustavo Roch', 200000, '1998-06-02');
insert into crud_partido values (5, 'REDE', 'Brasília', 'Pedro Ivo Batista', 20000, '2015-09-22');
insert into crud_partido values (6, 'PDT', 'Brasília', 'Carlos Lupi', 1000000, '1981-11-10');
insert into crud_partido values (7, 'SD', 'Brasília', 'Paulo Pereira da Silva', 160000, '2011-09-27');
insert into crud_partido values (8, 'DEM', 'Brasília', 'ACM Neto', 1000000, '2007-03-28');


insert into crud_cargo values (1, 'Presidente', 28000,'Chefe do Poder Executivo na esfera nacional');
insert into crud_cargo values (2, 'Governador', 25000,'Direção da administração estadual');
insert into crud_cargo values (3, 'Senador', 33000,'Propor novas leis, normas e alterações na Constituição');
insert into crud_cargo values (4, 'Deputado Federal', 33000,'Fiscalizar e controlar as ações do Poder Executivo');
insert into crud_cargo values (5, 'Deputado Estadual', 25000,'Fazer as leis dos estados');
insert into crud_cargo values (6, 'Prefeito', 15000,'Chefe do Poder Executivo na esfera municipal');
insert into crud_cargo values (7, 'Vereador', 13000,'Fiscalizar e cobrar ações do governo');
